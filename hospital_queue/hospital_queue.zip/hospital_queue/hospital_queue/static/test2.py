from datetime import datetime, timedelta
import pandas as pd

start_time = datetime(2025, 5, 6, 10, 0)
slot_duration = 15  # minutes
num_slots = 10

slots = []
for i in range(num_slots):
    slot_start = start_time + timedelta(minutes=i * slot_duration)
    slot_end = slot_start + timedelta(minutes=slot_duration)
    slots.append({
        "slot_id": i + 1,
        "start_time": slot_start.strftime("%Y-%m-%d %H:%M"),
        "end_time": slot_end.strftime("%Y-%m-%d %H:%M"),
        "doctor_id": "D1"
    })

df_slots = pd.DataFrame(slots)
df_slots.to_csv("static/doctor_appointment_slots.csv", index=False)
print(df_slots)
