from flask import Flask, request, render_template, redirect
import mysql.connector
from ortools.linear_solver import pywraplp

app = Flask(__name__)

# Native MySQL connector
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="appointment_scheduling"
)

def fetch(query, params=()):
    cursor = db.cursor(dictionary=True)
    cursor.execute(query, params)
    results = cursor.fetchall()
    cursor.close()
    return results

def execute(query, params=()):
    cursor = db.cursor()
    cursor.execute(query, params)
    db.commit()
    cursor.close()

@app.route('/', methods=['GET', 'POST'])
def book():
    if request.method == 'POST':
        execute("""
            INSERT INTO patients (name, priority, estimated_duration, preferred_time, doctor_preference)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            request.form['name'],
            int(request.form['priority']),
            int(request.form['duration']),
            request.form['preferred_time'],
            int(request.form['doctor_preference'])
        ))
        return redirect('/schedule')
    return render_template("booking.html")

@app.route('/schedule')
def schedule():
    patients = fetch("SELECT * FROM patients WHERE status = 'waiting'")
    doctors = fetch("SELECT * FROM doctors")
    time_slots = ['09:00','09:30','10:00','10:30','11:00','11:30']

    solver = pywraplp.Solver.CreateSolver('SCIP')
    x = {}

    for p in patients:
        for d in doctors:
            for t in time_slots:
                x[p['id'], d['id'], t] = solver.IntVar(0, 1, '')

    for p in patients:
        solver.Add(solver.Sum(x[p['id'], d['id'], t] for d in doctors for t in time_slots) == 1)

    for d in doctors:
        for t in time_slots:
            solver.Add(solver.Sum(x[p['id'], d['id'], t] for p in patients) <= 1)

    solver.Minimize(solver.Sum(
        p['priority'] * (int(t.split(':')[0]) * 60 + int(t.split(':')[1])) * x[p['id'], d['id'], t]
        for p in patients for d in doctors for t in time_slots
    ))

    results = []
    if solver.Solve() == pywraplp.Solver.OPTIMAL:
        for p in patients:
            for d in doctors:
                for t in time_slots:
                    if x[p['id'], d['id'], t].solution_value() == 1:
                        execute("INSERT INTO schedule (patient_id, doctor_id, time_slot) VALUES (%s, %s, %s)", (p['id'], d['id'], t))
                        execute("UPDATE patients SET status = 'scheduled' WHERE id = %s", (p['id'],))
                        results.append({'patient': p['name'], 'doctor': d['name'], 'time': t})

    return render_template("schedule.html", data=results)

if __name__ == '__main__':
    app.run(debug=True)
