import pandas as pd
import pulp

# Sample patient data with priorities
patients = pd.DataFrame({
    "patient_id": [1, 2, 3, 4, 5],
    "priority": [1, 2, 1, 2, 1]  # 1 = Regular, 2 = Emergency
})

slots = list(range(5))  # Available slots

model = pulp.LpProblem("Priority_Scheduling", pulp.LpMinimize)

# Decision variables: x[i][j] = 1 if patient i assigned to slot j
x = pulp.LpVariable.dicts("x", ((i, j) for i in patients.index for j in slots), cat="Binary")

# Objective: Minimize weighted wait time (priority * slot index)
model += pulp.lpSum(patients.loc[i, "priority"] * j * x[(i, j)] for i in patients.index for j in slots)

# Constraints: one slot per patient
for i in patients.index:
    model += pulp.lpSum(x[(i, j)] for j in slots) == 1

# Constraints: one patient per slot
for j in slots:
    model += pulp.lpSum(x[(i, j)] for i in patients.index) <= 1

# Solve
model.solve()

# Output schedule
schedule = []
for i in patients.index:
    for j in slots:
        if pulp.value(x[(i, j)]) == 1:
            schedule.append((patients.loc[i, "patient_id"], patients.loc[i, "priority"], j))

# Display
df_schedule = pd.DataFrame(schedule, columns=["patient_id", "priority", "assigned_slot"])
df_schedule = df_schedule.sort_values("assigned_slot")
print(df_schedule)
