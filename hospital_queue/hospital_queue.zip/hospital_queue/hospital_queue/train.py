import pandas as pd
import numpy as np
import mysql.connector
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler
from datetime import datetime

# DB connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="appointment_scheduling"
)

# Load data
df = pd.read_sql("SELECT * FROM ho_appoint WHERE consult_min IS NOT NULL", db)

# If empty - create dummy data
if df.empty:
    df = pd.DataFrame({
        'doctor_id':[1,1,1,2,2],
        'hour':[10,11,12,10,11],
        'day':[0,1,2,3,4],
        'consult_min':[10,15,20,12,18]
    })
else:
    df['start_time'] = pd.to_datetime(df['start_time'])
    df['hour'] = df['start_time'].dt.hour
    df['day'] = df['start_time'].dt.dayofweek

# Features
X = df[['doctor_id','hour','day']]
y = df['consult_min']

scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

X_scaled = X_scaled.reshape((X_scaled.shape[0],1,3))

model = Sequential()
model.add(LSTM(50, activation='relu', input_shape=(1,3)))
model.add(Dense(1))

model.compile(optimizer='adam', loss='mse')
model.fit(X_scaled, y, epochs=50)

model.save("consultation_model.h5")

print("Model trained successfully")
